"""
AWS Lambda entry point for the RFP Agent.
Triggered by API Gateway (HTTP) or EventBridge (scheduled).
"""
import json
import logging
import time
import sys, os

# Ensure /var/task root is on path for Lambda container
sys.path.insert(0, "/var/task")

from agent.rfp_agent import rfp_agent

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def handler(event, context):
    start_time = time.time()
    invocation_id = context.aws_request_id if context else "local"

    # Parse body — API Gateway sends body as string or dict
    body = event.get("body", {})
    if isinstance(body, str):
        try:
            body = json.loads(body)
        except json.JSONDecodeError:
            body = {}

    message = body.get("message", "").strip() if isinstance(body, dict) else ""

    # Structured log — invocation start
    logger.info(json.dumps({
        "event":          "invocation_start",
        "invocation_id":  invocation_id,
        "input_message":  message[:500],   # truncate to 500 chars
    }))

    # Validate input
    if not message:
        logger.info(json.dumps({
            "event":            "invocation_complete",
            "invocation_id":    invocation_id,
            "response_status":  400,
        }))
        return _response(400, {"error": "message field required"})

    # Invoke agent
    try:
        agent_response = rfp_agent(message)
        response_text  = str(agent_response)
        status_code    = 200
    except Exception as e:
        logger.error(json.dumps({
            "event":         "agent_error",
            "invocation_id": invocation_id,
            "error":         str(e),
        }))
        return _response(500, {"error": str(e)})

    duration_ms = int((time.time() - start_time) * 1000)

    # Structured log — invocation complete
    logger.info(json.dumps({
        "event":            "invocation_complete",
        "invocation_id":    invocation_id,
        "response_status":  status_code,
        "duration_ms":      duration_ms,
    }))

    return _response(200, {"response": response_text})


def _response(status_code: int, body: dict) -> dict:
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type":                "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body),
    }
